# Exercises
![Exercises 10](https://user-images.githubusercontent.com/70604577/229875879-802764d3-8e21-4f7a-8981-367470faa772.png)
![Exercises 10 2-final](https://user-images.githubusercontent.com/70604577/229875870-02b45e2f-dd8e-46d3-b03e-5d02fdf45aab.png)
![Exercises 10 3-final](https://user-images.githubusercontent.com/70604577/229875874-350a9d0a-2802-4297-9458-f49d6925d88e.png)
![Exercises 10 4](https://user-images.githubusercontent.com/70604577/229875877-453c7c0b-a5bc-472b-8672-ba0706b0cf0e.png)
