# Exercises
![Exercises 4](https://user-images.githubusercontent.com/70604577/229873464-54e7d304-f8a7-4fa7-8083-b1bc623f4058.png)
![Exercises 4 2](https://user-images.githubusercontent.com/70604577/229873460-3db9ba75-2d02-46e2-bab9-c94f90d1702b.png)
![Exercises 4 3](https://user-images.githubusercontent.com/70604577/229873463-352a7975-9d7c-4b31-8341-699adaa9a6a2.png)
